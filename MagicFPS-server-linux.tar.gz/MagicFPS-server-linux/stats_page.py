"""Blastcast player stats page (docs/PLAYER_STATS.md), served by crash_receiver.py at /stats?key=KEY.

Reads the server's match records (MF_STATS_DIR/server-YYYYMMDD.jsonl, written by magicfps_server) and the games'
play reports (MF_CRASH_DIR/stats/game-YYYYMMDD.jsonl, posted to /stats), and rolls them up into one HTML page:
weapons, abilities, transmogs, maps and heatmaps, pickup spots, players and retention, frame rates and network.
Each file is parsed once and cached until it changes, so opening the page costs the game server nothing.

  python3 stats_page.py SERVER_DIR GAME_DIR > stats.html     build the page from local copies (testing)
"""
import html
import json
import os
import sys
import time
from collections import Counter, defaultdict

_cache = {}  # path -> (mtime, size, [records])


def load(path):
    try:
        st = os.stat(path)
    except OSError:
        return []
    hit = _cache.get(path)
    if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
        return hit[2]
    out = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except ValueError:
                pass  # a cut-off line costs one record
    _cache[path] = (st.st_mtime, st.st_size, out)
    return out


def files(d, prefix):
    if not os.path.isdir(d):
        return []
    return sorted(os.path.join(d, f) for f in os.listdir(d) if f.startswith(prefix) and f.endswith(".jsonl"))


def day_of(path):
    return os.path.basename(path).split("-", 1)[1][:8]


def records(d, prefix, since_day):
    out = []
    for p in files(d, prefix):
        if day_of(p) >= since_day:
            out += load(p)
    return out


# ---------- formatting ----------

def esc(s):
    return html.escape(str(s), quote=True)


def fmt(v, d=0):
    if v is None:
        return "–"
    if isinstance(v, float):
        return f"{v:,.{d}f}"
    return f"{v:,}"


def pct(a, b):
    return f"{100.0 * a / b:.0f}%" if b else "–"


def table(cols, rows, bar_col=None, note=""):
    """cols: [(title, align)], rows: [[cell...]]; bar_col: index of a numeric column drawn as a bar too."""
    peak = max((r[bar_col] for r in rows if isinstance(r[bar_col], (int, float))), default=0) if bar_col is not None else 0
    h = ['<div class="tw"><table><thead><tr>']
    h += [f'<th class="{a}">{esc(t)}</th>' for t, a in cols]
    h.append("</tr></thead><tbody>")
    for r in rows:
        h.append("<tr>")
        for i, c in enumerate(r):
            a = cols[i][1]
            if i == bar_col and peak:
                w = 100.0 * (c or 0) / peak
                h.append(f'<td class="{a} bar"><span style="width:{w:.1f}%"></span><b>{fmt(c)}</b></td>')
            else:
                h.append(f'<td class="{a}">{c if isinstance(c, str) and c.startswith("<") else esc(fmt(c) if not isinstance(c, str) else c)}</td>')
        h.append("</tr>")
    if not rows:
        h.append(f'<tr><td colspan="{len(cols)}" class="empty">No data yet</td></tr>')
    h.append("</tbody></table></div>")
    if note:
        h.append(f'<p class="note">{esc(note)}</p>')
    return "".join(h)


def heatmap(points, spots, size=360, cells=36):
    """Top-down density of (x, z) points, with pickup spots as rings. Map +x right, +z down the page."""
    if not points:
        return '<p class="note">No kills on this map yet.</p>'
    xs = [p[0] for p in points] + [s[1] for s in spots]
    zs = [p[1] for p in points] + [s[2] for s in spots]
    x0, x1, z0, z1 = min(xs), max(xs), min(zs), max(zs)
    span = max(x1 - x0, z1 - z0, 1.0) * 1.08
    cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
    x0, z0 = cx - span / 2, cz - span / 2
    grid = Counter()
    for x, z in points:
        grid[(min(cells - 1, int((x - x0) / span * cells)), min(cells - 1, int((z - z0) / span * cells)))] += 1
    peak = max(grid.values())
    c = size / cells
    out = [f'<svg viewBox="0 0 {size} {size}" class="heat" role="img"><rect width="{size}" height="{size}" class="hbg"/>']
    for (i, j), n in grid.items():
        a = 0.15 + 0.85 * (n / peak) ** 0.6
        out.append(f'<rect x="{i * c:.1f}" y="{j * c:.1f}" width="{c:.1f}" height="{c:.1f}" fill="var(--heat)" fill-opacity="{a:.2f}"><title>{n}</title></rect>')
    for name, x, z, taken in spots:
        px, pz = (x - x0) / span * size, (z - z0) / span * size
        out.append(f'<circle cx="{px:.1f}" cy="{pz:.1f}" r="5" class="spot"><title>{esc(name)}: taken {taken}x</title></circle>')
    out.append("</svg>")
    return "".join(out)


# ---------- the page ----------

ABILITY_LABELS = {"vine": "Razor vine (grapple / yank)", "blink": "Storm Chain blink", "surf": "Worldbreaker surf",
                  "fire_sprint": "Burning Hands fire sprint", "frost_nova": "Frost Lance nova",
                  "thermal_boost": "Fireball thermal boost", "boulder_roll": "Boulder roll",
                  "holy_ward": "Magic Missiles holy ward", "lunge": "Blade lunge"}


def build(server_dir, game_dir, query):
    days = query.get("days", "30")
    who = query.get("who", "humans")
    pick_map = query.get("map", "")
    since = "00000000" if days == "all" else time.strftime("%Y%m%d", time.gmtime(time.time() - 86400 * int(days)))
    matches = records(server_dir, "server-", since)
    games = records(game_dir, "game-", since)
    if pick_map:
        matches = [m for m in matches if m.get("map") == pick_map]

    def counted(p):
        return who == "all" or (who == "bots") == bool(p.get("bot"))

    # --- overview
    humans = set()
    total_sec = 0
    for m in matches:
        total_sec += m.get("sec", 0)
        for p in m.get("players", []):
            if not p.get("bot"):
                humans.add(p.get("name"))
    ids = {g.get("id") for g in games if g.get("id")}

    # --- weapons
    W = defaultdict(lambda: Counter())
    for m in matches:
        for p in m.get("players", []):
            if not counted(p):
                continue
            for name, w in p.get("weapons", {}).items():
                c = W[name]
                for k in ("picks", "held", "shots", "throws", "hits", "hs", "k", "d", "dmg", "ttk_n", "ttk_sum"):
                    c[k] += w.get(k, 0)
    wrows = []
    for name, c in W.items():
        acc = pct(c["hits"], c["shots"]) if c["shots"] else "–"
        ttk = f'{c["ttk_sum"] / c["ttk_n"]:.2f} s' if c["ttk_n"] else "–"
        kpm = f'{c["k"] / (c["held"] / 60):.2f}' if c["held"] > 60 else "–"
        wrows.append([name, c["k"], c["picks"], fmt(c["held"] / 60, 1), c["shots"] or c["throws"], acc,
                      c["hs"], c["d"], c["dmg"], ttk, kpm])
    wrows.sort(key=lambda r: -r[1])

    # --- abilities and transmogs
    A = defaultdict(Counter)
    T = defaultdict(Counter)
    for m in matches:
        for p in m.get("players", []):
            if not counted(p):
                continue
            for name, a in p.get("abilities", {}).items():
                A[name]["n"] += a.get("n", 0)
                A[name]["k"] += a.get("k", 0)
                A[name]["chilled"] += a.get("chilled", 0)
            for name, t in p.get("transmogs", {}).items():
                for k in ("n", "sec", "k", "d"):
                    T[name][k] += t.get(k, 0)
    arows = sorted(([ABILITY_LABELS.get(n, n), c["n"], c["k"], pct(c["k"], c["n"])] for n, c in A.items()), key=lambda r: -r[1])
    trows = sorted(([n, c["n"], fmt(c["sec"] / 60, 1), c["k"], c["d"], fmt(c["k"] / max(c["d"], 1), 2)] for n, c in T.items()),
                   key=lambda r: -r[1])

    # --- maps and modes
    M = defaultdict(Counter)
    modes = Counter()
    causes = Counter()
    for m in matches:
        c = M[m.get("map", "?")]
        c["n"] += 1
        c["sec"] += m.get("sec", 0)
        c["humans"] += m.get("humans", 0)
        modes[m.get("mode", "?")] += 1
        for k in m.get("kills", []):
            c["kills"] += 1
            if k[3] & 4:
                c["spawn"] += 1
            if k[2] not in ("spell", "melee", "grenade", "lunge", "assassination", "surf", "flag_swing"):
                causes[k[2]] += 1
        for p in m.get("players", []):
            if not p.get("bot") and p.get("left") is not None:
                c["quits"] += 1
                if p.get("rage_quit"):
                    c["rage"] += 1
    mrows = sorted(([n, c["n"], fmt(c["sec"] / c["n"] / 60, 1), fmt(c["humans"] / c["n"], 1),
                     fmt(c["kills"] / max(c["sec"] / 60, 1), 1), pct(c["spawn"], c["kills"]), c["quits"], c["rage"]]
                    for n, c in M.items()), key=lambda r: -r[1])

    # --- heatmaps and pickup spots (one map)
    maps = sorted({m.get("map", "?") for m in records(server_dir, "server-", since)})
    hm_map = pick_map or (mrows[0][0] if mrows else "")
    deaths, spot_taken, spot_info, hm_matches = [], Counter(), {}, 0
    for m in matches:
        if m.get("map") != hm_map:
            continue
        hm_matches += 1
        for k in m.get("kills", []):
            if who == "all" or (who == "bots") == bool(k[3] & 2):
                deaths.append((k[4], k[6]))
        for i, s in enumerate(m.get("pickup_spots", [])):
            spot_info[i] = s[:3]
            spot_taken[i] += s[3]
    spots = [(spot_info[i][0], spot_info[i][1], spot_info[i][2], spot_taken[i]) for i in sorted(spot_info)]
    srows = sorted(([s[0], f"{s[1]:.0f}, {s[2]:.0f}", s[3], fmt(s[3] / max(hm_matches, 1), 1)] for s in spots), key=lambda r: -r[2])

    # --- players (server records: names) and retention (game reports: anonymous ids)
    P = defaultdict(Counter)
    last_seen = {}
    elo = {}
    for m in matches:
        for p in m.get("players", []):
            if p.get("bot"):
                continue
            n = p.get("name", "?")
            c = P[n]
            c["n"] += 1
            for k in ("k", "d", "a", "dmg", "spawn_deaths", "stinky"):
                c[k] += p.get(k, 0)
            shots = sum(w.get("shots", 0) for w in p.get("weapons", {}).values())
            hits = sum(w.get("hits", 0) for w in p.get("weapons", {}).values())
            c["shots"] += shots
            c["hits"] += hits
            if p.get("left") is not None:
                c["quits"] += 1
            if p.get("rage_quit"):
                c["rage"] += 1
            if p.get("ping") is not None:
                c["ping_n"] += 1
                c["ping"] += p["ping"]
                c["jitter"] += p.get("jitter", 0)
                c["loss"] += p.get("loss", 0)
            if m.get("teams") and m.get("winning_team"):
                c["team_games"] += 1
                c["wins"] += p.get("team") == m["winning_team"]
            if m.get("end", "") >= last_seen.get(n, ""):
                last_seen[n] = m.get("end", "")
                elo[n] = p.get("elo1") or p.get("elo0")
    prows = sorted(([n, c["n"], c["k"], c["d"], fmt(c["k"] / max(c["d"], 1), 2), pct(c["hits"], c["shots"]),
                     c["stinky"], pct(c["wins"], c["team_games"]), elo.get(n) or "–", c["quits"], c["rage"],
                     fmt(c["ping"] / c["ping_n"], 0) if c["ping_n"] else "–",
                     fmt(c["jitter"] / c["ping_n"], 1) if c["ping_n"] else "–",
                     pct(c["loss"], c["ping_n"]) if c["ping_n"] else "–", last_seen.get(n, "")[:16].replace("T", " ")]
                    for n, c in P.items()), key=lambda r: -r[1])

    by_day = defaultdict(set)
    first_day = {}
    for g in games:
        i, d = g.get("id"), (g.get("start") or "")[:10]
        if not i or not d:
            continue
        by_day[d].add(i)
        first_day[i] = min(first_day.get(i, d), d)
    rrows = []
    for d in sorted(by_day, reverse=True)[:30]:
        ids_d = by_day[d]
        new = sum(1 for i in ids_d if first_day[i] == d)
        rrows.append([d, len(ids_d), new, len(ids_d) - new])
    returned = sum(1 for i in first_day if any(i in s for d, s in by_day.items() if d > first_day[i]))

    # --- frame rates and machines
    G = defaultdict(list)
    MF = defaultdict(list)
    os_c, res_c, detail_c = Counter(), Counter(), Counter()
    pad = []
    for g in games:
        if not g.get("frames"):
            continue
        G[g.get("gpu") or "?"].append(g)
        MF[g.get("map") or "?"].append(g)
        os_c[g.get("os", "?")] += 1
        res_c[g.get("res", "?")] += 1
        detail_c[g.get("detail", "?")] += 1
        pad.append(g.get("pad", 0))

    def med(v):
        v = sorted(v)
        return v[len(v) // 2] if v else None

    def frows(groups):
        return sorted(([n, len({x.get("id") for x in gs}), len(gs), med([x.get("fps", 0) for x in gs]),
                        med([x.get("low1_fps", 0) for x in gs]), med([x.get("worst_ms", 0) for x in gs]),
                        sum(x.get("over40", 0) for x in gs)] for n, gs in groups.items()), key=lambda r: -r[2])
    gpu_rows = [[r[0], r[1], r[2], fmt(r[3], 0), fmt(r[4], 0), fmt(r[5], 0), r[6]] for r in frows(G)]
    map_fps = [[r[0], r[1], r[2], fmt(r[3], 0), fmt(r[4], 0), fmt(r[5], 0), r[6]] for r in frows(MF)]
    cpu_c = Counter(g.get("cpu") or "?" for g in games)

    # --- team balance: does the higher-rated team win?
    fav_games = fav_wins = 0
    for m in matches:
        if not m.get("teams") or not m.get("winning_team"):
            continue
        avg = defaultdict(list)
        for p in m.get("players", []):
            if p.get("elo0"):
                avg[p.get("team")].append(p["elo0"])
        if len(avg) < 2:
            continue
        means = {t: sum(v) / len(v) for t, v in avg.items()}
        best = max(means, key=means.get)
        if sorted(means.values())[-1] - sorted(means.values())[-2] < 25:
            continue  # an even match
        fav_games += 1
        fav_wins += best == m["winning_team"]

    # ---------- HTML ----------
    def link(**kw):
        q = {"key": query.get("key", ""), "days": days, "who": who, "map": pick_map}
        q.update(kw)
        return "?" + "&".join(f"{k}={esc(v)}" for k, v in q.items() if v != "")

    def chips(param, options, current):
        return "".join(f'<a class="chip{" on" if str(v) == str(current) else ""}" href="{link(**{param: v})}">{esc(t)}</a>'
                       for v, t in options)

    tiles = [("Matches", fmt(len(matches))), ("Hours played", fmt(total_sec / 3600, 1)),
             ("Named players", fmt(len(humans))), ("Installs seen", fmt(len(ids))),
             ("Came back another day", pct(returned, len(first_day))),
             ("Controller share", pct(sum(pad), len(pad)))]
    body = [f'<header><h1>Blastcast player stats</h1><p class="sub">Generated {time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())}. '
            f'Who: {esc(who)}. Maps: {esc(pick_map or "all")}.</p>',
            '<nav>' + chips("days", [("1", "24 h"), ("7", "7 days"), ("30", "30 days"), ("all", "All")], days) + '<span class="sep"></span>'
            + chips("who", [("humans", "Humans"), ("bots", "Bots"), ("all", "Everyone")], who) + '<span class="sep"></span>'
            + chips("map", [("", "All maps")] + [(m, m) for m in maps], pick_map) + "</nav></header>",
            '<section class="tiles">' + "".join(f'<div class="tile"><div class="v">{v}</div><div class="l">{esc(t)}</div></div>' for t, v in tiles) + "</section>"]

    body.append("<h2>Weapons</h2>")
    body.append(table([("Weapon", "l"), ("Kills", "r"), ("Pickups", "r"), ("Minutes in hand", "r"), ("Shots / throws", "r"),
                       ("Accuracy", "r"), ("Headshots", "r"), ("Deaths holding", "r"), ("Damage", "r"), ("Avg TTK", "r"),
                       ("Kills / min held", "r")], wrows, bar_col=1,
                      note="Sorted by kills; the bottom rows are the least used. Accuracy counts aimed spells only. TTK = first hit on the victim (since their shields last recharged) to the kill."))
    body.append('<div class="two"><div><h2>Weapon abilities</h2>')
    body.append(table([("Ability", "l"), ("Uses", "r"), ("Kills within 3 s", "r"), ("Kill rate", "r")], arows, bar_col=1))
    body.append("</div><div><h2>Transmogs</h2>")
    body.append(table([("Form", "l"), ("Uses", "r"), ("Minutes", "r"), ("Kills", "r"), ("Deaths", "r"), ("K/D", "r")], trows))
    body.append("</div></div>")

    body.append("<h2>Maps</h2>")
    body.append(table([("Map", "l"), ("Matches", "r"), ("Avg minutes", "r"), ("Humans / match", "r"), ("Kills / min", "r"),
                       ("Spawn kills", "r"), ("Quits", "r"), ("Rage quits", "r")], mrows, bar_col=1,
                      note="Spawn kill = died within 5 s of spawning. Rage quit = left within 15 s of dying while behind."))
    mode_rows = [[k, v] for k, v in modes.most_common()]
    cause_rows = [[k.replace("_", " "), v] for k, v in causes.most_common()]
    body.append('<div class="two"><div><h3>Modes</h3>' + table([("Mode", "l"), ("Matches", "r")], mode_rows, bar_col=1) +
                '</div><div><h3>Hazard and environment kills</h3>' + table([("Cause", "l"), ("Kills", "r")], cause_rows, bar_col=1) + "</div></div>")
    if fav_games:
        body.append(f'<p class="note">Team balance: in {fav_games} team matches with a clear Elo favourite (25+ points), '
                    f'the higher-rated team won {pct(fav_wins, fav_games)}.</p>')

    body.append(f"<h2>Where people die: {esc(hm_map or '–')}</h2>")
    body.append('<p class="note">Top-down; darker = more deaths. Rings are weapon spots (hover for how often each was taken). '
                'Pick a map above to switch.</p>')
    body.append('<div class="two"><div>' + heatmap(deaths, spots) + "</div><div>" +
                table([("Spot", "l"), ("Where (x, z)", "r"), ("Taken", "r"), ("Per match", "r")], srows, bar_col=2) + "</div></div>")

    body.append("<h2>Players</h2>")
    body.append(table([("Name", "l"), ("Matches", "r"), ("Kills", "r"), ("Deaths", "r"), ("K/D", "r"), ("Accuracy", "r"),
                       ("Stinky kills", "r"), ("Team win %", "r"), ("Elo", "r"), ("Quits", "r"), ("Rage quits", "r"), ("Ping", "r"),
                       ("Jitter", "r"), ("Loss", "r"), ("Last seen (UTC)", "r")], prows, bar_col=1))
    body.append("<h3>Daily players (by anonymous install id)</h3>")
    body.append(table([("Day", "l"), ("Players", "r"), ("New", "r"), ("Returning", "r")], rrows, bar_col=1))

    body.append("<h2>Frame rate</h2>")
    fcols = [("", "l"), ("Players", "r"), ("Reports", "r"), ("Median FPS", "r"), ("1% low FPS", "r"), ("Worst frame ms", "r"), ("Frames over 40 ms", "r")]
    body.append("<h3>By graphics card</h3>" + table([("GPU", "l")] + fcols[1:], gpu_rows))
    body.append("<h3>By map</h3>" + table([("Map", "l")] + fcols[1:], map_fps))
    small = lambda c, t: table([(t, "l"), ("Reports", "r")], [[k, v] for k, v in c.most_common(12)], bar_col=1)
    body.append('<div class="three"><div><h3>OS</h3>' + small(os_c, "OS") + '</div><div><h3>Resolution</h3>' + small(res_c, "Resolution") +
                '</div><div><h3>Detail</h3>' + small(detail_c, "Detail") + "</div></div>")
    body.append("<h3>CPUs</h3>" + small(cpu_c, "CPU"))
    body.append(f'<p class="note">Raw data: <a href="/stats/files?key={esc(query.get("key", ""))}">the daily files</a>.</p>')
    return PAGE.replace("{BODY}", "\n".join(body))


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Blastcast player stats</title><style>
:root{--bg:#f6f4ef;--card:#fff;--ink:#1d1b26;--mute:#6b6878;--line:#e3e0d8;--accent:#6a4cff;--bar:#d9d1ff;--heat:#e2462f;--hbg:#efece4}
@media (prefers-color-scheme:dark){:root{--bg:#15141b;--card:#1e1d26;--ink:#ecebf3;--mute:#9a97a8;--line:#2d2b38;--accent:#9d88ff;--bar:#3a3165;--heat:#ff6a4d;--hbg:#24232d}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,Segoe UI,sans-serif;padding:24px 16px 64px;max-width:1200px;margin:auto}
h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:36px 0 10px}h3{font-size:14px;margin:18px 0 8px;color:var(--mute)}
.sub,.note{color:var(--mute);font-size:12.5px}nav{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0}
.chip{padding:4px 10px;border:1px solid var(--line);border-radius:99px;color:var(--ink);text-decoration:none;font-size:12.5px;background:var(--card)}
.chip.on{background:var(--accent);border-color:var(--accent);color:#fff}.sep{width:10px}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:16px}
.tile{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px}.tile .v{font-size:22px;font-weight:650}.tile .l{color:var(--mute);font-size:12px}
.tw{overflow-x:auto;background:var(--card);border:1px solid var(--line);border-radius:10px}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{padding:6px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
th{font-size:12px;color:var(--mute);font-weight:600;text-align:left}.r{text-align:right}tr:last-child td{border-bottom:0}
td.bar{position:relative;min-width:110px}td.bar span{position:absolute;left:0;top:4px;bottom:4px;background:var(--bar);border-radius:3px}td.bar b{position:relative;font-weight:500}
.empty{color:var(--mute);text-align:center}.two{display:grid;grid-template-columns:1fr 1fr;gap:16px}.three{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
@media (max-width:800px){.two,.three{grid-template-columns:1fr}}
.heat{width:100%;max-width:420px;border-radius:10px;border:1px solid var(--line)}.hbg{fill:var(--hbg)}.spot{fill:none;stroke:var(--accent);stroke-width:2}
a{color:var(--accent)}
</style></head><body>{BODY}</body></html>"""


def file_list(server_dir, game_dir, key):
    rows = [f'<li><a href="/stats/raw/{esc(os.path.basename(p))}?key={esc(key)}">{esc(os.path.basename(p))}</a> '
            f'({os.path.getsize(p):,} bytes)</li>' for p in sorted(files(server_dir, "server-") + files(game_dir, "game-"), reverse=True)]
    return PAGE.replace("{BODY}", "<h1>Raw player stats files</h1><p class='note'>One JSON record per line "
                        "(docs/PLAYER_STATS.md).</p><ul>" + "".join(rows) + "</ul>")


def raw_path(server_dir, game_dir, name):
    for p in files(server_dir, "server-") + files(game_dir, "game-"):
        if os.path.basename(p) == name:  # only names the listing has: no paths
            return p
    return None


if __name__ == "__main__":
    sys.stdout.write(build(sys.argv[1], sys.argv[2], dict(a.split("=", 1) for a in sys.argv[3:])))
