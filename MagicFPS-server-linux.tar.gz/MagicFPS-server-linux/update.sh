#!/usr/bin/env bash
# Blastcast server self-updater. Installed to /opt/magicfps/update.sh; magicfps-update.timer runs it every
# 10 minutes. CI publishes every build to the public repo chedenis/magic-fps-releases (release "latest",
# assets VERSION.txt, MagicFPS-windows.zip, MagicFPS-server-linux.tar.gz), so no token is needed.
# When the published VERSION.txt differs from /opt/magicfps/VERSION.txt it downloads the server package
# and runs its install.sh. It waits while players are connected (per /run/magicfps/status), for at most
# 6 hours, so nobody is kicked mid-match.
#   update.sh        check once (what the timer runs)
#   update.sh --now  update now even with players connected
set -euo pipefail
# The braces make bash read the whole script before running it: install.sh replaces this file mid-run.
{
BASE=${MF_UPDATE_BASE:-https://github.com/chedenis/magic-fps-releases/releases/latest/download}
ASSET=MagicFPS-server-linux.tar.gz
INSTALL_DIR=${MF_INSTALL_DIR:-/opt/magicfps}
STATUS_FILE=${MF_STATUS_FILE:-/run/magicfps/status}
STATE_DIR=${MF_STATE_DIR:-/var/lib/magicfps}
MAX_DEFER_SEC=${MF_MAX_DEFER_SEC:-21600}

fetch() { curl -fsSL --max-time 300 "$@"; }

mkdir -p "$STATE_DIR"
exec 9>"$STATE_DIR/update.lock"
flock -n 9 || { echo "another update is running"; exit 0; }

remote=$(fetch "$BASE/VERSION.txt" | tr -d '\r' | head -n1) || {
    echo "could not read $BASE/VERSION.txt (offline, or no release published yet)"; exit 0; }
[ -n "$remote" ] || { echo "the published VERSION.txt is empty"; exit 0; }
local_version=$(tr -d '\r' 2>/dev/null < "$INSTALL_DIR/VERSION.txt" || true)
if [ "$remote" = "$local_version" ]; then
    echo "up to date ($remote)"
    rm -f "$STATE_DIR/pending_since"
    exit 0
fi

if [ "${1:-}" != "--now" ]; then
    clients=$(sed -n 's/^clients \([0-9]*\)$/\1/p' "$STATUS_FILE" 2>/dev/null || true)
    if [ -n "$clients" ] && [ "$clients" -gt 0 ]; then
        now=$(date +%s)
        [ -s "$STATE_DIR/pending_since" ] || echo "$now" > "$STATE_DIR/pending_since"
        waited=$((now - $(cat "$STATE_DIR/pending_since")))
        if [ "$waited" -lt "$MAX_DEFER_SEC" ]; then
            echo "$remote is available; waiting for $clients player(s) to leave (${waited}s so far)"
            exit 0
        fi
        echo "$remote has waited ${waited}s for an empty server; updating anyway"
    fi
fi

work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
echo "updating ${local_version:-nothing} -> $remote"
fetch -o "$work/$ASSET" "$BASE/$ASSET"
tar -xzf "$work/$ASSET" -C "$work"
pkg="$work/MagicFPS-server-linux"
[ -x "$pkg/magicfps_server" ] && [ -x "$pkg/install.sh" ] || { echo "the download is not a server package" >&2; exit 1; }
"$pkg/install.sh"
rm -f "$STATE_DIR/pending_since"
exit 0
}
