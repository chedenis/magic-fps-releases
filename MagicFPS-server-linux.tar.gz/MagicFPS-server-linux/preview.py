#!/usr/bin/env python3
"""Blastcast Preview downloads (docs/PREVIEW_DOWNLOADS.md): the newest Preview build for Ches's computers, from any
computer, without the laptop.

GitHub builds a Preview of main every few hours (.github/workflows/preview.yml) and keeps it on the private repo's
release "preview". This server fetches it (a token that can only read the repo) and hands it out over HTTP to whoever
has the key. The Preview's launchers check here every time they start (tools/preview/preview_update.ps1).

    preview.py sync      fetch a newer Preview from GitHub (magicfps-preview-sync.timer, every 5 minutes)
    preview.py serve     the download page on TCP 27961 (magicfps-preview-web.service)
    preview.py url       print the page's address, key included
    preview.py check     check the token can read the release

  GET /preview?key=K                     the page: version, download button, what's new
  GET /preview/VERSION.txt?key=K         what the launchers compare (also BUILT.txt, WHATS_NEW.txt)
  GET /preview/Blastcast-Preview.zip?key=K
  GET /preview/wip?key=K                 work in progress: each branch's changed models, textures and maps
  GET /preview/wip/blob/SHA?key=K        one of those files (fly mode's B key loads them over the Preview)

Each zip handed out carries preview_server.txt (this page's address with the key), so a Preview downloaded here
keeps updating from here. The key is /etc/magicfps/preview.key (made by preview_install.sh); a new key reaches every
Preview with its next update. Plain HTTP, like /stats: the key keeps strangers out, not someone on the network path.
"""
import calendar
import hashlib
import hmac
import html
import json
import os
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

REPO = os.environ.get("MF_PREVIEW_REPO", "chedenis/magic-fps")
TAG = "preview"
API = os.environ.get("MF_GITHUB_API", "https://api.github.com")
DIR = os.environ.get("MF_PREVIEW_DIR", "/var/lib/magicfps-preview")
TOKEN_FILE = os.environ.get("MF_PREVIEW_TOKEN_FILE", "/etc/magicfps/preview.token")
KEY_FILE = os.environ.get("MF_PREVIEW_KEY_FILE", "/etc/magicfps/preview.key")
HOST_FILE = os.environ.get("MF_PREVIEW_HOST_FILE", "/etc/magicfps/preview.host")
PORT = int(os.environ.get("MF_PREVIEW_PORT", "27961"))
ZIP = "Blastcast-Preview.zip"
TEXTS = ("VERSION.txt", "BUILT.txt", "WHATS_NEW.txt")


def read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def page_url():
    return f"http://{read(HOST_FILE) or 'SERVER'}:{PORT}/preview?key={read(KEY_FILE)}"


# ---------------------------------------------------------------------------------------------------------------------
# sync: GitHub release "preview" -> DIR

class StripAuthOnRedirect(urllib.request.HTTPRedirectHandler):
    """Release assets redirect to a signed storage URL that refuses a second credential: drop the token there."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
            new.remove_header("Authorization")
        return new


opener = urllib.request.build_opener(StripAuthOnRedirect)


def github(url, token, accept="application/vnd.github+json"):
    req = urllib.request.Request(url if url.startswith("http") else API + url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", accept)
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "blastcast-preview")
    return opener.open(req, timeout=60)


def release(token):
    with github(f"/repos/{REPO}/releases/tags/{TAG}", token) as r:
        rel = json.loads(r.read())
    return {a["name"]: a["url"] for a in rel.get("assets", [])}


def asset_text(url, token):
    with github(url, token, "application/octet-stream") as r:
        return r.read().decode("utf-8", "replace").strip()


def stamp(zip_path, server_txt):
    """Adds preview_server.txt to the zip (appended: the 150 MB of game data are not rewritten)."""
    with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as z:
        if "MagicFPS-Preview/preview_server.txt" not in z.namelist():
            z.writestr("MagicFPS-Preview/preview_server.txt", server_txt)


def sync(token):
    os.makedirs(DIR, exist_ok=True)
    assets = release(token)
    if ZIP not in assets or "VERSION.txt" not in assets:
        print("the preview release has no build yet")
        return 0
    version = asset_text(assets["VERSION.txt"], token)
    key = read(KEY_FILE)
    key_id = hashlib.sha256(key.encode()).hexdigest()[:16]  # which key the zip carries, without the key itself
    have = read(os.path.join(DIR, "VERSION.txt"))
    if version == have and read(os.path.join(DIR, ".key")) == key_id:
        return 0
    tmp = os.path.join(DIR, ".download.zip")
    with github(assets[ZIP], token, "application/octet-stream") as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f, 1 << 20)
    with zipfile.ZipFile(tmp) as z:
        if z.testzip() is not None:
            raise RuntimeError("the downloaded zip is damaged")
        inner = z.read("MagicFPS-Preview/VERSION.txt").decode("utf-8", "replace").strip()
        if inner != version:  # the release is mid-upload: VERSION.txt goes up last, so try next time
            print(f"release is being updated (zip has {inner!r}, VERSION.txt says {version!r})")
            os.remove(tmp)
            return 0
        texts = {n: z.read(f"MagicFPS-Preview/{n}") if f"MagicFPS-Preview/{n}" in z.namelist() else b""
                 for n in TEXTS}
    stamp(tmp, page_url() + "\r\n")
    os.replace(tmp, os.path.join(DIR, ZIP))
    for name in TEXTS:  # VERSION.txt last: the page and the launchers go by it
        with open(os.path.join(DIR, name + ".new"), "wb") as f:
            f.write(texts[name])
        os.replace(os.path.join(DIR, name + ".new"), os.path.join(DIR, name))
    with open(os.path.join(DIR, ".key"), "w") as f:
        f.write(key_id)
    print(f"now serving {version}")
    return 0


# ---------------------------------------------------------------------------------------------------------------------
# sync: work in progress. The WIP_MAX newest branches with a commit in the last WIP_DAYS days that change art (models, textures,
# maps, light bakes, skies) against main is listed in DIR/wip/index.txt, its files kept by git blob id in
# DIR/wip/blobs. Fly mode lists the branches and loads a branch's files over the Preview (docs/PREVIEW_DOWNLOADS.md).

WIP_DAYS = 7
WIP_MAX = 10   # newest branches listed (old batch branches carry hundreds of MB of art main already has)
WIP_DIRS = ("assets/models/", "assets/maps/", "assets/bake/", "assets/skies/")
WIP_EXTS = (".mfm", ".png", ".map", ".bake")


def github_json(path, token):
    with github(path, token) as r:
        return json.loads(r.read())


def wip_branches(token):
    """[(name, head sha)] of every branch but main."""
    out, page = [], 1
    while True:
        rows = github_json(f"/repos/{REPO}/branches?per_page=100&page={page}", token)
        out += [(b["name"], b["commit"]["sha"]) for b in rows if b["name"] != "main"]
        if len(rows) < 100:
            return out
        page += 1


def recent(when):
    return time.time() - calendar.timegm(time.strptime(when, "%Y-%m-%dT%H:%M:%SZ")) < WIP_DAYS * 86400


def wip_entry(name, head, token):
    """The branch's art changes against main, or None (no art, or nothing in the last WIP_DAYS days)."""
    try:
        cmp = github_json(f"/repos/{REPO}/compare/main...{urllib.parse.quote(name, safe='/')}", token)
    except urllib.error.HTTPError as e:
        if e.code in (404, 422):  # no history in common with main
            return None
        raise
    commits = cmp.get("commits") or []
    if not commits:
        return None
    newest = commits[-1]["commit"]
    when = newest["committer"]["date"]
    if not recent(when):
        return None
    files = [(f["filename"][len("assets/"):], f["sha"]) for f in cmp.get("files", [])
             if f["status"] != "removed" and f["filename"].startswith(WIP_DIRS) and f["filename"].endswith(WIP_EXTS)]
    if not files:
        return None
    title = next((c["commit"]["message"].splitlines()[0] for c in reversed(commits)
                  if not c["commit"]["message"].startswith(("WIP", "Merge"))), newest["message"].splitlines()[0])
    return {"branch": name, "head": head, "title": title, "when": when, "files": sorted(files)}


def wip_index_text(entries):
    lines = ["# Blastcast work in progress: branches with art changes against main, newest first"]
    for e in entries:
        lines += [f"branch {e['branch']}", f"title {e['title']}", f"when {e['when']}", f"head {e['head']}"]
        lines += [f"file {rel} {sha}" for rel, sha in e["files"]]
        lines.append("end")
    return "\n".join(lines) + "\n"


def sync_wip(token):
    wip = os.path.join(DIR, "wip")
    blobs = os.path.join(wip, "blobs")
    os.makedirs(blobs, exist_ok=True)
    try:
        with open(os.path.join(wip, "state.json")) as f:
            known = json.load(f)  # branch -> {"head": sha, "entry": its art changes or None} as seen last time
    except (OSError, ValueError):
        known = {}
    now = {}
    for name, head in wip_branches(token):
        seen = known.get(name)
        now[name] = seen if seen and seen.get("head") == head else {"head": head, "entry": wip_entry(name, head, token)}
    entries = sorted((b["entry"] for b in now.values() if b["entry"] and recent(b["entry"]["when"])), key=lambda e: e["when"], reverse=True)[:WIP_MAX]
    wanted = {sha for e in entries for _, sha in e["files"]}
    for sha in wanted:
        path = os.path.join(blobs, sha)
        if os.path.exists(path):
            continue
        with github(f"/repos/{REPO}/git/blobs/{sha}", token, "application/vnd.github.raw") as r, \
                open(path + ".part", "wb") as f:
            shutil.copyfileobj(r, f, 1 << 20)
        os.replace(path + ".part", path)
    for name in os.listdir(blobs):  # files no branch lists any more
        if name not in wanted:
            os.remove(os.path.join(blobs, name))
    with open(os.path.join(wip, "index.txt.new"), "w", encoding="utf-8") as f:
        f.write(wip_index_text(entries))
    os.replace(os.path.join(wip, "index.txt.new"), os.path.join(wip, "index.txt"))
    with open(os.path.join(wip, "state.json"), "w") as f:
        json.dump(now, f)
    return entries


# ---------------------------------------------------------------------------------------------------------------------
# serve: the page and the files

PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Blastcast Preview</title>
<style>
:root {{ --bg: #10162a; --card: #1a2340; --ink: #eef2ff; --dim: #a9b4d6; --gold: #f2b544; --line: #2c3866; }}
body {{ margin: 0; background: var(--bg); color: var(--ink); font: 16px/1.5 system-ui, sans-serif; }}
main {{ max-width: 760px; margin: 0 auto; padding: 32px 16px 48px; }}
h1 {{ margin: 0 0 4px; font-size: 30px; letter-spacing: .04em; }}
.sub {{ color: var(--dim); margin: 0 0 24px; }}
.card {{ background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 20px; margin-bottom: 20px; }}
a.btn {{ display: inline-block; background: var(--gold); color: #1b1200; font-weight: 700; text-decoration: none;
        padding: 12px 22px; border-radius: 8px; font-size: 18px; }}
ol {{ margin: 12px 0 0; padding-left: 22px; color: var(--dim); }}
ul {{ list-style: none; margin: 0; padding: 0; }}
li.new {{ padding: 7px 0; border-top: 1px solid var(--line); }}
li.new:first-child {{ border-top: 0; }}
.day {{ color: var(--dim); font-size: 13px; display: block; }}
h2 {{ font-size: 18px; margin: 0 0 10px; }}
</style></head><body><main>
<h1>Blastcast Preview</h1>
<p class="sub">{version} &middot; code from {built}</p>
<div class="card">
<a class="btn" href="/preview/{zipname}?key={key}">Download the Preview ({size} MB)</a>
<ol>
<li>Unzip it anywhere (a computer that has a Preview already updates itself: just start it).</li>
<li>Double-click <b>Play Preview</b> to play, or <b>Fly mode</b> to fly around a map. P takes a screenshot for Claude.</li>
<li>Every launcher checks here first, so you're always on the newest build.</li>
</ol>
</div>
<div class="card"><h2>{heading}</h2><ul>{items}</ul></div>
</main></body></html>
"""


def page(key):
    version = read(os.path.join(DIR, "VERSION.txt"))
    if not version:
        return "<!doctype html><title>Blastcast Preview</title><p>No Preview here yet: the first one arrives a few " \
               "minutes after GitHub builds it.</p>"
    lines = read(os.path.join(DIR, "WHATS_NEW.txt")).splitlines() or ["What's new"]
    items = []
    for line in lines[1:]:
        day, _, text = line.partition("  ")
        items.append(f'<li class="new"><span class="day">{html.escape(day)}</span>{html.escape(text)}</li>')
    size = os.path.getsize(os.path.join(DIR, ZIP)) // (1 << 20)
    built = read(os.path.join(DIR, "BUILT.txt")).replace("T", " ").replace("Z", " UTC") or "unknown"
    return PAGE.format(version=html.escape(version), built=html.escape(built), zipname=zip_name(version),
                       key=urllib.parse.quote(key), size=size, heading=html.escape(lines[0]), items="".join(items))


def zip_name(version):
    """A new file name for every build, so a browser or OneDrive never hands back an older download."""
    sha = version.rsplit("(", 1)[-1].strip(")")[:7] if "(" in version else "build"
    return f"Blastcast-Preview-{sha}.zip"


class Handler(BaseHTTPRequestHandler):
    def reply(self, code, body, ctype="text/plain; charset=utf-8"):
        body = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        if url.path == "/health":
            return self.reply(200, "ok\n")
        if url.path != "/preview" and not url.path.startswith("/preview/"):
            return self.reply(404, "not found\n")
        key = read(KEY_FILE)
        given = urllib.parse.parse_qs(url.query).get("key", [""])[-1]
        if not key or not hmac.compare_digest(given, key):
            return self.reply(403, "add ?key=... (run preview.py url on the server for the address)\n")
        name = url.path[len("/preview/"):] if url.path.startswith("/preview/") else ""
        if name == "":
            return self.reply(200, page(key), "text/html; charset=utf-8")
        if name == "wip":
            path = os.path.join(DIR, "wip", "index.txt")
            return self.reply(200, open(path, "rb").read()) if os.path.exists(path) else self.reply(200, "")
        if name.startswith("wip/blob/"):
            sha = name[len("wip/blob/"):]
            path = os.path.join(DIR, "wip", "blobs", sha)
            if len(sha) != 40 or not all(c in "0123456789abcdef" for c in sha) or not os.path.exists(path):
                return self.reply(404, "not found\n")
            return self.reply(200, open(path, "rb").read(), "application/octet-stream")
        if name in TEXTS:
            path = os.path.join(DIR, name)
            return self.reply(200, open(path, "rb").read()) if os.path.exists(path) else self.reply(404, "none yet\n")
        if name == ZIP or (name.startswith("Blastcast-Preview-") and name.endswith(".zip")):
            path = os.path.join(DIR, ZIP)
            if not os.path.exists(path):
                return self.reply(404, "none yet\n")
            with open(path, "rb") as f:  # the open file survives a sync replacing it mid-download
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(os.fstat(f.fileno()).st_size))
                self.send_header("Content-Disposition", f'attachment; filename="{name}"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                shutil.copyfileobj(f, self.wfile, 1 << 20)
            return
        self.reply(404, "not found\n")

    def log_message(self, *args):
        pass  # no IPs in the journal


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "url"
    if cmd == "serve":
        ThreadingHTTPServer(("", PORT), Handler).serve_forever()
    if cmd == "url":
        print(page_url())
        return 0
    token = read(TOKEN_FILE)
    if not token:
        print(f"no token in {TOKEN_FILE}: run preview_install.sh (docs/PREVIEW_DOWNLOADS.md)", file=sys.stderr)
        return 0 if cmd == "sync" else 1
    if cmd == "check":
        try:
            assets = release(token)
            print("token OK; the preview release has", ", ".join(sorted(assets)) or "no files yet")
        except urllib.error.HTTPError as e:
            if e.code != 404:
                print(f"GitHub said {e.code}: the token can't read {REPO} (it needs Contents: read)", file=sys.stderr)
                return 1
            try:
                with github(f"/repos/{REPO}", token):
                    pass
            except urllib.error.HTTPError as e2:
                print(f"GitHub said {e2.code}: the token can't read {REPO} (it needs Contents: read)", file=sys.stderr)
                return 1
            print("token OK; GitHub hasn't built the first Preview yet")
        return 0
    if cmd == "sync":
        rc = 0
        try:
            rc = sync(token)
        except urllib.error.HTTPError as e:
            print(f"GitHub said {e.code}" + (" (no Preview built yet)" if e.code == 404 else ""), file=sys.stderr)
            rc = 0 if e.code == 404 else 1
        try:  # work in progress, whatever happened to the build
            entries = sync_wip(token)
            print(f"work in progress: {len(entries)} branches with art changes")
        except (urllib.error.URLError, OSError, KeyError, ValueError) as e:
            print(f"work in progress: {e!r}", file=sys.stderr)
            rc = 1
        return rc
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
