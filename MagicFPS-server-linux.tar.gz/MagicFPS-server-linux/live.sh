#!/usr/bin/env bash
# Blastcast live file (docs/LIVE_FILE.md): the server's own balance numbers and pickup placement, changed without a
# release. The server re-reads /etc/magicfps/live.txt twice a second (balance at once, pickups between matches) and
# updates never replace it. Installed to /opt/magicfps/live.sh and as the command magicfps-live:
#   magicfps-live                   what the live file changes now, and where it comes from
#   magicfps-live edit              edit it by hand (nano), then check it
#   magicfps-live connect TOKEN     fetch it from GitHub every minute: TOKEN is a read-only GitHub token for
#                                   chedenis/magic-fps (Contents: read); the file is live.txt on the repo's "live" branch
#   magicfps-live connect TOKEN URL the same from another address (a raw file URL; TOKEN "-" for none)
#   magicfps-live disconnect        stop fetching (the file stays as it is)
#   magicfps-live fetch             fetch once now (what magicfps-live.timer runs every minute)
# A fetched file with a mistake in it never reaches players: the last good one stays, and the journal says why
# (journalctl -u magicfps-live). A hand edit stays until the GitHub copy changes.
set -euo pipefail
LIVE=${MF_LIVE_FILE:-/etc/magicfps/live.txt}
LIVE_ENV=${MF_LIVE_ENV:-/etc/magicfps/live.env}
STATE_DIR=${MF_STATE_DIR:-/var/lib/magicfps}
SERVER_BIN=${MF_SERVER_BIN:-/opt/magicfps/magicfps_server}
DEFAULT_URL=https://api.github.com/repos/chedenis/magic-fps/contents/live.txt?ref=live

check() { "$SERVER_BIN" --check-live "$1"; }

fetch() {
    [ -f "$LIVE_ENV" ] || { echo "not connected (magicfps-live connect TOKEN)"; return 0; }
    # shellcheck disable=SC1090
    . "$LIVE_ENV"
    [ -n "${MF_LIVE_URL:-}" ] || { echo "no MF_LIVE_URL in $LIVE_ENV"; return 0; }
    mkdir -p "$STATE_DIR"
    local tmp hdr=()
    tmp=$(mktemp)
    trap 'rm -f "$tmp"' RETURN
    [ -n "${MF_LIVE_TOKEN:-}" ] && hdr=(-H "Authorization: Bearer $MF_LIVE_TOKEN")
    if ! curl -fsSL --max-time 30 "${hdr[@]}" -H "Accept: application/vnd.github.raw" -o "$tmp" "$MF_LIVE_URL"; then
        echo "could not fetch $MF_LIVE_URL (offline, a wrong token, or no live branch yet)"
        return 0
    fi
    local sum
    sum=$(sha256sum < "$tmp" | cut -d' ' -f1)
    [ "$sum" = "$(cat "$STATE_DIR/live.fetched" 2>/dev/null || true)" ] && return 0  # unchanged since the last fetch
    if ! out=$(check "$tmp" 2>&1); then
        if [ "$sum" != "$(cat "$STATE_DIR/live.rejected" 2>/dev/null || true)" ]; then
            echo "the new live file has mistakes; players keep the last good one:"
            echo "$out"
            echo "$sum" > "$STATE_DIR/live.rejected"
        fi
        return 0
    fi
    install -m 644 "$tmp" "$LIVE.new"
    mv -f "$LIVE.new" "$LIVE"
    echo "$sum" > "$STATE_DIR/live.fetched"
    echo "live file updated:"
    echo "$out"
}

case "${1:-}" in
    "")
        if [ -f "$LIVE_ENV" ]; then (. "$LIVE_ENV"; echo "fetching every minute from ${MF_LIVE_URL:-?}"); else echo "not fetching (magicfps-live connect TOKEN)"; fi
        [ -s "$LIVE" ] && check "$LIVE" || echo "no live file: the shipped balance and map files" ;;
    edit)
        "${EDITOR:-nano}" "$LIVE"
        check "$LIVE" && echo "saved: balance applies within a second, pickups from the next match" ;;
    connect)
        token=${2:-}
        [ -n "$token" ] || { echo "usage: magicfps-live connect TOKEN [URL]" >&2; exit 1; }
        [ "$token" = - ] && token=""
        umask 077
        printf 'MF_LIVE_URL=%s\nMF_LIVE_TOKEN=%s\n' "${3:-$DEFAULT_URL}" "$token" > "$LIVE_ENV"
        chmod 600 "$LIVE_ENV"
        rm -f "$STATE_DIR/live.fetched" "$STATE_DIR/live.rejected"
        systemctl enable --now magicfps-live.timer >/dev/null 2>&1 || true
        fetch ;;
    disconnect)
        rm -f "$LIVE_ENV"
        echo "stopped fetching; $LIVE stays as it is" ;;
    fetch) fetch ;;
    *) sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
