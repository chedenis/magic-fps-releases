#!/usr/bin/env bash
# Installs or upgrades Blastcast Bot (docs/DISCORD.md) on a Linux host. Any host works: the bot reaches the game
# servers over the network. The game server package carries it, so a server's install.sh runs this too; on a host of
# its own, blastcast-bot-update.timer keeps it current. It only starts once blastcast-bot-setup has stored the bot's
# token. Run as root. A fresh host (Ubuntu), in one line:
#   curl -fsSL https://github.com/chedenis/magic-fps-releases/releases/latest/download/MagicFPS-server-linux.tar.gz |
#     tar -xz -C /tmp && /tmp/MagicFPS-server-linux/discord-bot/install.sh && blastcast-bot-setup
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
install -d -m 755 /opt/blastcast-bot /etc/blastcast-bot
install -m 644 "$here/blastcast_bot.py" /opt/blastcast-bot/blastcast_bot.py
[ -f /etc/blastcast-bot/servers.txt ] || install -m 644 "$here/servers.txt" /etc/blastcast-bot/servers.txt
install -m 755 "$here/blastcast-bot-setup" /usr/local/bin/blastcast-bot-setup
printf '#!/bin/sh\nexec /usr/bin/python3 /opt/blastcast-bot/blastcast_bot.py "${@:-dry-run}"\n' > /usr/local/bin/blastcast-bot
chmod 755 /usr/local/bin/blastcast-bot
install -m 755 "$here/update.sh" /opt/blastcast-bot/update.sh
for unit in blastcast-bot.service blastcast-bot-update.service blastcast-bot-update.timer; do
    install -m 644 "$here/$unit" "/etc/systemd/system/$unit"
done
systemctl daemon-reload
# A host of its own updates itself; a game server's updater already reinstalls the bot with each build.
[ -x /opt/magicfps/magicfps_server ] || systemctl enable --now blastcast-bot-update.timer >/dev/null 2>&1
if [ -s /etc/blastcast-bot/token ]; then
    systemctl enable blastcast-bot >/dev/null 2>&1
    systemctl restart blastcast-bot
fi
