#!/usr/bin/env bash
# Keeps Blastcast Bot current on a host that isn't a game server (docs/DISCORD.md). blastcast-bot-update.timer runs
# it hourly: when the published build differs from the one installed, it takes the bot out of the public game server
# package and reinstalls it. (On a game server the server's own updater already does this.)
set -euo pipefail
BASE=${BB_UPDATE_BASE:-https://github.com/chedenis/magic-fps-releases/releases/latest/download}
[ -x /opt/magicfps/magicfps_server ] && { echo "a game server host: its updater keeps the bot current"; exit 0; }
remote=$(curl -fsSL --max-time 60 "$BASE/VERSION.txt" | tr -d '\r' | head -n1) || { echo "could not read VERSION.txt"; exit 0; }
[ -n "$remote" ] || exit 0
[ "$remote" = "$(cat /opt/blastcast-bot/VERSION.txt 2>/dev/null || true)" ] && { echo "up to date ($remote)"; exit 0; }
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
curl -fsSL --max-time 300 -o "$work/s.tar.gz" "$BASE/MagicFPS-server-linux.tar.gz"
tar -xzf "$work/s.tar.gz" -C "$work" MagicFPS-server-linux/discord-bot MagicFPS-server-linux/VERSION.txt
"$work/MagicFPS-server-linux/discord-bot/install.sh"
install -m 644 "$work/MagicFPS-server-linux/VERSION.txt" /opt/blastcast-bot/VERSION.txt
echo "updated to $remote"
