#!/usr/bin/env python3
"""Blastcast Bot (docs/DISCORD.md): the live server board in the Blastcast Discord. One bot for every game server:
it asks each server on its list for its rooms over the network, the way the game's PLAY ONLINE browser does (the room
query, engine/net/rooms.cpp), so no game server runs Discord code and adding a server is one line in servers.txt.

Every 15 seconds it:
  1. keeps one pinned message in #server-status up to date: each server up or down, its rooms' map, mode, phase and
     players;
  2. tells staff in #ops-alerts when a server has stopped answering for 90 s, and when it's back;
  3. publishes the patch notes GitHub posts into #patch-notes (an announcement channel), so servers that follow the
     channel get them too. The notes and crash alerts themselves come from GitHub (.github/workflows/discord-*.yml).

Does nothing until /etc/blastcast-bot/token exists (blastcast-bot-setup writes it). Stdlib only.
  blastcast-bot run        the service loop
  blastcast-bot once       one pass, then exit
  blastcast-bot dry-run    one pass that prints what it would send instead of sending it
  blastcast-bot check      test the token, connect once, find the Discord server, its channels and the game servers
  blastcast-bot invite     the link that adds the bot to a Discord server
"""
import base64
import json
import os
import random
import re
import select
import socket
import ssl
import struct
import sys
import time
import urllib.error
import urllib.request

CONFIG = os.environ.get("BB_CONFIG_DIR", "/etc/blastcast-bot")
TOKEN_FILE = os.environ.get("BB_TOKEN_FILE", os.path.join(CONFIG, "token"))
SERVERS_FILE = os.environ.get("BB_SERVERS_FILE", os.path.join(CONFIG, "servers.txt"))
STATE_FILE = os.environ.get("BB_STATE", "/var/lib/blastcast-bot/state.json")
GUILD = os.environ.get("BB_GUILD", "")  # only needed if the bot is in more than one Discord server
CHANNELS = {"status": os.environ.get("BB_STATUS_CHANNEL", "server-status"),
            "notes": os.environ.get("BB_NOTES_CHANNEL", "patch-notes"),
            "alerts": os.environ.get("BB_ALERTS_CHANNEL", "ops-alerts")}
API = "https://discord.com/api/v10"
USER_AGENT = "DiscordBot (https://blastcastgame.com, 1) Blastcast"
PERIOD = 15              # seconds between passes
DOWN_AFTER = 3           # missed queries in a row before a server counts as down (one lost packet isn't an outage)
DOWN_ALERT_AFTER = 90    # seconds down before staff hear about it (an update's restart takes a few)
# View Channel, Send Messages, Manage Messages (publishing in an announcement channel), Embed Links, Read Message
# History, Pin Messages (its board): what the invite asks for. Never Administrator.
PERMISSIONS = (1 << 10) | (1 << 11) | (1 << 13) | (1 << 14) | (1 << 16) | (1 << 51)
GREEN, RED, GOLD = 0x45CF80, 0xE5484D, 0xF2B544

# The room query (engine/net/rooms.h RoomPacket, blastcast/net/net.h kProtocolMagic): any protocol version gets an
# answer, so the bot never needs updating when the game's protocol changes.
MAGIC = 0x4D465053        # "MFPS"
ROOM_QUERY, ROOM_LIST = 13, 14
QUERY_PADDING = 600       # kRoomQueryPadding: a server ignores shorter queries
MAX_ROOMS = 8


# ---------------------------------------------------------------------------------------------------------------------
# The game's wire format: a little-endian bit stream (engine BitWriter), strings as a 5-bit length then bytes

class Bits:
    def __init__(self, data=b""):
        self.data, self.pos = bytearray(data), 0
        self.overflow = False

    def write(self, value, bits):
        for i in range(bits):
            if self.pos % 8 == 0:
                self.data.append(0)
            if value >> i & 1:
                self.data[-1] |= 1 << (self.pos % 8)
            self.pos += 1

    def read(self, bits):
        v = 0
        for i in range(bits):
            if self.pos >= len(self.data) * 8:
                self.overflow = True
                return 0
            if self.data[self.pos >> 3] >> (self.pos & 7) & 1:
                v |= 1 << i
            self.pos += 1
        return v

    def write_str(self, s, max_len=20):
        b = s.encode()[:max_len]
        self.write(len(b), 5)
        for c in b:
            self.write(c, 8)

    def read_str(self, max_len=20):
        n = self.read(5)
        if n > max_len:
            self.overflow = True
            return ""
        return bytes(self.read(8) for _ in range(n)).decode("utf-8", "replace")


def room_query(nonce):
    w = Bits()
    w.write(ROOM_QUERY, 8)
    w.write(MAGIC, 32)
    w.write(0, 16)  # our protocol version: any is answered; we only read
    w.write(nonce, 32)
    return bytes(w.data) + bytes(QUERY_PADDING - len(w.data))


def parse_room_list(data, nonce):
    """A server's answer: {version, max_rooms, rooms: [{port, players, max, map, mode, phase}]}, or None."""
    r = Bits(data)
    if r.read(8) != ROOM_LIST or r.read(32) != MAGIC or r.read(32) != nonce:
        return None
    out = {"version": r.read(16), "max_rooms": r.read(8)}
    r.read(16)  # new room port (answers to NEW ROOM only)
    n = r.read(8)
    if r.overflow or n > MAX_ROOMS:
        return None
    rooms = []
    for _ in range(n):
        rooms.append({"port": r.read(16), "players": r.read(8), "max": r.read(8), "map": r.read_str(),
                      "mode": r.read_str(), "phase": r.read_str()})
    if r.overflow:
        return None
    out["rooms"] = rooms
    return out


def query_server(host, port, timeout=1.5):
    """Asks one game server for its rooms; resends every 0.4 s like the game does. None if it doesn't answer."""
    nonce = random.getrandbits(32)
    q = room_query(nonce)
    try:
        addr = socket.getaddrinfo(host, port, type=socket.SOCK_DGRAM)[0]
    except OSError:
        return None
    s = socket.socket(addr[0], socket.SOCK_DGRAM)
    try:
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            s.sendto(q, addr[4])
            wait_until = min(end, time.monotonic() + 0.4)
            while time.monotonic() < wait_until:
                ready, _, _ = select.select([s], [], [], max(0.0, wait_until - time.monotonic()))
                if not ready:
                    break
                data, _ = s.recvfrom(2048)
                ans = parse_room_list(data, nonce)
                if ans is not None:
                    return ans
    except OSError:
        return None
    finally:
        s.close()
    return None


def parse_servers(text):
    """servers.txt: one game server per line, `Name host[:port]`; # starts a comment."""
    out = []
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        name, _, addr = line.rpartition(" ")
        host, _, port = addr.partition(":")
        out.append({"name": name.strip() or host, "host": host, "port": int(port or 27960)})
    return out


# ---------------------------------------------------------------------------------------------------------------------
# What the Discord sees (pure functions; tools/ops/test_blastcast_bot.py covers them)

PHASES = {"lobby": "In the lobby", "countdown": "Starting", "playing": "In a match", "postgame": "Match over"}


def board_embed(servers, now):
    """The #server-status board. `servers`: [{name, up, since, answer}]."""
    people = sum(r["players"] for s in servers if s["up"] for r in s["answer"]["rooms"])
    up = [s for s in servers if s["up"]]
    blocks = []
    for s in servers:
        if not s["up"]:
            blocks.append(f"🔴 **{s['name']}** · down since <t:{int(s['since'])}:R>")
            continue
        rooms = s["answer"]["rooms"]
        lines = [f"🟢 **{s['name']}** · {sum(r['players'] for r in rooms)} playing"]
        for i, r in enumerate(rooms):
            lines.append(f"Room {i + 1} · {r['map'] or 'Loading'} · {r['mode']} · {PHASES.get(r['phase'], 'Open')} · "
                         f"{r['players']}/{r['max']}")
        blocks.append("\n".join(lines))
    if not servers:
        blocks.append("No game servers on the list yet.")
    color = GREEN if len(up) == len(servers) and servers else (GOLD if up else RED)
    head = f"**{people} {'person' if people == 1 else 'people'} playing**"
    return {"title": "Blastcast servers", "color": color,
            "description": head + "\n\n" + "\n\n".join(blocks) +
                           "\n\nJoin from **PLAY ONLINE** in the game. Bots fill every match.",
            "footer": {"text": "Updates live"}}


def board_key(embed):
    """What has to change before the board is edited (Discord rate-limits edits; player counts are what matter)."""
    return json.dumps(embed, sort_keys=True)


# ---------------------------------------------------------------------------------------------------------------------
# Discord

class DiscordError(Exception):
    def __init__(self, status, text):
        super().__init__(f"Discord said {status}: {text[:300]}")
        self.status = status


class Discord:
    def __init__(self, token, dry=False):
        self.token = token
        self.dry = dry

    def call(self, method, path, body=None):
        if self.dry and method != "GET":
            print(f"[dry-run] {method} {path} {json.dumps(body)[:600] if body else ''}", flush=True)
            return {"id": "dry"}
        data = json.dumps(body).encode() if body is not None else None
        for _ in range(3):
            req = urllib.request.Request(API + path, data=data, method=method, headers={
                "Authorization": f"Bot {self.token}", "User-Agent": USER_AGENT, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=20) as r:
                    raw = r.read()
                    return json.loads(raw) if raw else {}
            except urllib.error.HTTPError as e:
                text = e.read().decode("utf-8", "replace")
                if e.code == 429:
                    try:
                        wait = float(json.loads(text).get("retry_after", 2))
                    except ValueError:
                        wait = 2
                    time.sleep(min(wait, 30) + 0.1)
                    continue
                raise DiscordError(e.code, text)
        raise DiscordError(429, "still rate limited")

    def send(self, channel, embed):
        return self.call("POST", f"/channels/{channel}/messages", {"embeds": [embed], "allowed_mentions": {"parse": []}})


def gateway_hello(token, host="gateway.discord.gg", port=443, tls=True):
    """Connects to Discord's gateway once and identifies. Discord requires a bot to have done this before it may send
    messages; the service itself only uses the REST API. Returns the bot's user name from READY."""
    raw = socket.create_connection((host, port), timeout=20)
    s = ssl.create_default_context().wrap_socket(raw, server_hostname=host) if tls else raw
    key = base64.b64encode(os.urandom(16)).decode()
    s.sendall((f"GET /?v=10&encoding=json HTTP/1.1\r\nHost: {host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nUser-Agent: {USER_AGENT}\r\n\r\n").encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = s.recv(4096)
        if not chunk:
            raise RuntimeError("the gateway closed the connection")
        buf += chunk
    head, buf = buf.split(b"\r\n\r\n", 1)
    if b" 101 " not in head.split(b"\r\n")[0]:
        raise RuntimeError(f"the gateway refused the connection: {head.splitlines()[0]!r}")

    def read_exact(n):
        nonlocal buf
        while len(buf) < n:
            chunk = s.recv(65536)
            if not chunk:
                raise RuntimeError("the gateway closed the connection")
            buf += chunk
        out, buf = buf[:n], buf[n:]
        return out

    def recv_msg():
        data = b""
        while True:
            b0, b1 = read_exact(2)
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack(">H", read_exact(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", read_exact(8))[0]
            payload = read_exact(n)
            op = b0 & 0x0F
            if op == 8:
                code = struct.unpack(">H", payload[:2])[0] if len(payload) >= 2 else 0
                raise RuntimeError(f"the gateway closed with {code} {payload[2:].decode('utf-8', 'replace')}"
                                   + (" (wrong token)" if code == 4004 else ""))
            if op in (0, 1, 2):
                data += payload
                if b0 & 0x80:
                    return json.loads(data)

    def send_msg(obj, opcode=1):
        payload = json.dumps(obj).encode() if opcode == 1 else obj
        n = len(payload)
        hdr = bytes([0x80 | opcode])
        hdr += bytes([0x80 | n]) if n < 126 else (bytes([0x80 | 126]) + struct.pack(">H", n) if n < 65536
                                                  else bytes([0x80 | 127]) + struct.pack(">Q", n))
        mask = os.urandom(4)
        s.sendall(hdr + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    try:
        hello = recv_msg()
        if hello.get("op") != 10:
            raise RuntimeError(f"unexpected first message from the gateway: {hello.get('op')}")
        send_msg({"op": 2, "d": {"token": token, "intents": 0,
                                 "properties": {"os": "linux", "browser": "blastcast", "device": "blastcast"}}})
        while True:
            msg = recv_msg()
            if msg.get("op") == 0 and msg.get("t") == "READY":
                return msg["d"]["user"]["username"]
            if msg.get("op") == 9:
                raise RuntimeError("the gateway rejected the login")
    finally:
        try:
            send_msg(struct.pack(">H", 1000), opcode=8)
        except OSError:
            pass
        s.close()


def find_channels(dc):
    """The Discord server the bot is in, and the ids of the channels it posts to."""
    guilds = dc.call("GET", "/users/@me/guilds")
    if GUILD:
        guilds = [g for g in guilds if g["id"] == GUILD or g["name"] == GUILD]
    if not guilds:
        return None, {}
    if len(guilds) > 1:
        raise RuntimeError("the bot is in several Discord servers: set BB_GUILD in /etc/blastcast-bot/bot.env to one "
                           f"of {', '.join(g['name'] for g in guilds)}")
    g = guilds[0]
    chans = dc.call("GET", f"/guilds/{g['id']}/channels")
    ids = {}
    for role, name in CHANNELS.items():
        for c in chans:
            if c.get("type") in (0, 5) and c.get("name") == name:  # text or announcement channel
                ids[role] = {"id": c["id"], "announce": c["type"] == 5}
    return g, ids


def invite_url(app_id):
    return f"https://discord.com/oauth2/authorize?client_id={app_id}&scope=bot&permissions={PERMISSIONS}"


# ---------------------------------------------------------------------------------------------------------------------
# One pass

def read(path, default=""):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return default


def load_state():
    try:
        return json.loads(read(STATE_FILE, "{}") or "{}")
    except ValueError:
        return {}


def save_state(state):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f, indent=1)
    os.replace(tmp, STATE_FILE)


def poll_servers(state, now, query=None):
    """Asks every server on the list; returns [{name, up, since, answer, came_back}] and keeps each one's history."""
    query = query or query_server
    seen = state.setdefault("servers", {})
    out = []
    for srv in parse_servers(read(SERVERS_FILE)):
        key = f"{srv['host']}:{srv['port']}"
        h = seen.setdefault(key, {"up": None, "since": now, "misses": 0})
        ans = query(srv["host"], srv["port"])
        if ans is not None:
            h["misses"], h["answer"] = 0, ans
        else:
            h["misses"] += 1
        up = ans is not None or (h["up"] is not False and h["misses"] < DOWN_AFTER and "answer" in h)
        came_back = False
        if up != h["up"]:
            came_back = up and bool(h.get("down_alerted"))
            h["up"], h["since"] = up, now
            h.pop("down_alerted", None)
        out.append({"name": srv["name"], "key": key, "up": up, "since": h["since"], "answer": h.get("answer"),
                    "came_back": came_back})
    return out


def pass_board(dc, state, ch, servers, now):
    embed = board_embed(servers, now)
    if "status" not in ch:
        return
    key = board_key(embed)
    cid = ch["status"]["id"]
    mid = state.get("status_message") if state.get("status_channel") == cid else None
    if key == state.get("status_key") and mid:
        return
    body = {"embeds": [embed], "allowed_mentions": {"parse": []}}
    try:
        if not mid:
            raise DiscordError(404, "no board yet")
        dc.call("PATCH", f"/channels/{cid}/messages/{mid}", body)
    except DiscordError as e:
        if e.status != 404:
            raise
        m = dc.call("POST", f"/channels/{cid}/messages", body)  # first run, or someone deleted the board
        state["status_message"], state["status_channel"] = m.get("id"), cid
        try:
            dc.call("PUT", f"/channels/{cid}/messages/pins/{m.get('id')}")
        except DiscordError as pe:
            print(f"couldn't pin the status board: {pe}", flush=True)
    state["status_key"] = key


def pass_alerts(dc, state, ch, servers, now):
    if "alerts" not in ch:
        return
    cid = ch["alerts"]["id"]
    for s in servers:
        h = state["servers"][s["key"]]
        if not s["up"] and now - s["since"] >= DOWN_ALERT_AFTER and not h.get("down_alerted"):
            dc.send(cid, {"title": f"{s['name']} is down", "color": RED,
                          "description": f"No answer to the room query since <t:{int(s['since'])}:R>. "
                                         "`journalctl -u magicfps -n 100` on it, or an `ops:logs` issue (docs/OPS.md)."})
            h["down_alerted"] = True
        if s["came_back"]:
            dc.send(cid, {"title": f"{s['name']} is back", "color": GREEN,
                          "description": f"Answering again, protocol {s['answer']['version']}."})


def pass_publish(dc, state, ch):
    """Publishes what GitHub's workflow posted in #patch-notes to every server that follows the channel."""
    notes = ch.get("notes")
    if not notes or not notes["announce"]:
        return
    done = state.setdefault("published", [])
    for m in dc.call("GET", f"/channels/{notes['id']}/messages?limit=10"):
        if m.get("webhook_id") and not (m.get("flags", 0) & 1) and m["id"] not in done:
            dc.call("POST", f"/channels/{notes['id']}/messages/{m['id']}/crosspost")
            done.append(m["id"])
    state["published"] = done[-50:]


def one_pass(dc, state, query=None):
    now = time.time()
    if now - state.get("channels_at", 0) > 600 or not state.get("channels"):
        _, state["channels"] = find_channels(dc)
        state["channels_at"] = now
    ch = state["channels"]
    servers = poll_servers(state, now, query)
    for name, fn in (("board", lambda: pass_board(dc, state, ch, servers, now)),
                     ("alerts", lambda: pass_alerts(dc, state, ch, servers, now)),
                     ("publish", lambda: pass_publish(dc, state, ch))):
        try:
            fn()
        except DiscordError as e:
            hint = (" (give Blastcast Bot View Channel and Send Messages there: docs/DISCORD.md)"
                    if e.status == 403 else "")
            print(f"{name}: {e}{hint}", flush=True)


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "once"
    token = read(TOKEN_FILE).strip()
    if not token:
        print(f"no token in {TOKEN_FILE}: run blastcast-bot-setup (docs/DISCORD.md)")
        return 0 if cmd in ("run", "once") else 1
    dc = Discord(token, dry=cmd == "dry-run")
    if cmd == "check":
        me = dc.call("GET", "/users/@me")
        app = dc.call("GET", "/oauth2/applications/@me")
        print(f"token works: {me['username']} (application {app['id']})")
        print(f"connected to the gateway as {gateway_hello(token)}")
        ok = True
        for srv in parse_servers(read(SERVERS_FILE)) or [None]:
            if srv is None:
                print(f"no game servers in {SERVERS_FILE}")
                ok = False
                continue
            ans = query_server(srv["host"], srv["port"])
            print(f"  {srv['name']} ({srv['host']}:{srv['port']}): " +
                  (f"{len(ans['rooms'])} room(s), protocol {ans['version']}" if ans else "NOT ANSWERING"))
            ok = ok and ans is not None
        g, ids = find_channels(dc)
        if not g:
            print(f"the bot isn't in a Discord server yet. Open this link and add it to Blastcast:\n  {invite_url(app['id'])}")
            return 1
        print(f"in {g['name']}")
        for role, name in CHANNELS.items():
            print(f"  #{name}: {'found' if role in ids else 'MISSING'}")
        return 0 if ok and len(ids) == len(CHANNELS) else 1
    if cmd == "invite":
        print(invite_url(dc.call("GET", "/oauth2/applications/@me")["id"]))
        return 0
    state = load_state()
    if cmd in ("once", "dry-run"):
        one_pass(dc, state)
        if cmd == "once":
            save_state(state)
        return 0
    if cmd == "run":
        print("Blastcast Bot running", flush=True)
        while True:
            try:
                one_pass(dc, state)
                save_state(state)
            except Exception as e:  # never let one bad pass stop the bot; systemd restarts it if it dies anyway
                print(f"pass failed: {e!r}", flush=True)
            time.sleep(PERIOD)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
