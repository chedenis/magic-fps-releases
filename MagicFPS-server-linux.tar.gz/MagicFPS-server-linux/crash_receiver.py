#!/usr/bin/env python3
"""Blastcast crash report receiver (docs/CRASHES.md). Players' games POST the previous run's log here when it crashed,
froze or logged errors (unless crash_reports=0); the ops relay (ops_relay.py, docs/OPS.md) files them as GitHub issues.

It also serves performance reports (docs/PERF_REPORTS.md), so they can be read in a browser without SSH:
  GET  /perf          the newest match reports (the server's, from MF_PERF_DIR) and hitch reports (players' games)
  GET  /perf/NAME     one report
  POST /perf          a game's hitch report (frame times and its worst hitches; no names, no IPs)

and player stats (docs/PLAYER_STATS.md):
  POST /stats         a game's play report (one JSON line: frame rate, machine, controller use, anonymous id, name)
  GET  /stats?key=K   the stats page (K is in /etc/magicfps/stats.key); /stats/files and /stats/raw/NAME the raw files

Listens on TCP 27960 (the game uses UDP 27960; different protocols, no clash). Each report is saved as
/var/lib/magicfps-crashes/YYYYmmdd-HHMMSS-N.txt. Senders' IPs are only used for the rate limit, never stored.
  magicfps-crashes          list the reports
  magicfps-crashes show N   print the newest-but-N report (0 = newest)
"""
import hmac
import json
import os
import re
import sys
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stats_page  # noqa: E402

DIR = os.environ.get("MF_CRASH_DIR", "/var/lib/magicfps-crashes")
PORT = int(os.environ.get("MF_CRASH_PORT", "27960"))
PERF_DIR = os.environ.get("MF_PERF_DIR", "/var/lib/magicfps/perf")  # the server's match reports (--perf-dir)
HITCH_DIR = os.path.join(DIR, "hitches")                             # games' hitch reports
STATS_DIR = os.environ.get("MF_STATS_DIR", "/var/lib/magicfps/stats")  # the server's match records (--stats-dir)
GAME_STATS_DIR = os.path.join(DIR, "stats")                            # games' play reports
STATS_KEY_FILE = os.environ.get("MF_STATS_KEY_FILE", "/etc/magicfps/stats.key")
STATS_MAX_BYTES = 8 * 1024
STATS_PER_IP_PER_HOUR = 60
STATS_KEEP_DAYS = 366
MAX_BYTES = 64 * 1024     # matches kCrashReportMaxBytes in the game
KEEP = 500                # newest reports kept (at most ~32 MB)
PER_IP_PER_HOUR = 10

recent = {}  # (ip, kind) -> [times]


def stats_key():
    try:
        with open(STATS_KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def save_play_report(data):
    """One JSON line in stats/game-YYYYMMDD.jsonl; only the fields the game sends, checked."""
    rec = json.loads(data)
    if not isinstance(rec, dict) or rec.get("kind") != "game" or not re.fullmatch(r"[0-9a-f]{16}", str(rec.get("id", ""))):
        raise ValueError("not a play report")
    rec = {k: v for k, v in rec.items() if isinstance(v, (str, int, float, bool)) and len(str(v)) <= 200}
    rec["received"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    os.makedirs(GAME_STATS_DIR, exist_ok=True)
    name = os.path.join(GAME_STATS_DIR, time.strftime("game-%Y%m%d.jsonl", time.gmtime()))
    with open(name, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, separators=(",", ":")) + "\n")
    old = sorted(f for f in os.listdir(GAME_STATS_DIR) if f.endswith(".jsonl"))
    for f in old[:-STATS_KEEP_DAYS]:
        os.remove(os.path.join(GAME_STATS_DIR, f))


def prune(d=DIR):
    files = sorted(f for f in os.listdir(d) if f.endswith(".txt"))
    for f in files[:-KEEP]:
        os.remove(os.path.join(d, f))


def save(d, data):
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    i = 0
    while os.path.exists(os.path.join(d, f"{stamp}-{i}.txt")):
        i += 1
    name = f"{stamp}-{i}.txt"
    with open(os.path.join(d, name), "w", encoding="utf-8") as f:
        f.write(data)
    prune(d)
    return name


def perf_files():
    """(kind, dir, name) of every report, newest first."""
    out = []
    for kind, d in (("match", PERF_DIR), ("hitch", HITCH_DIR)):
        if os.path.isdir(d):
            out += [(kind, d, f) for f in os.listdir(d) if f.endswith(".txt")]
    return sorted(out, key=lambda x: x[2], reverse=True)


def perf_index():
    """Plain text: one line per report, with its headline, newest first."""
    lines = ["Blastcast performance reports (newest first). Open one: /perf/NAME", ""]
    for kind, d, name in perf_files()[:200]:
        try:
            with open(os.path.join(d, name), encoding="utf-8", errors="replace") as f:
                head = [f.readline().strip() for _ in range(4)]
        except OSError:
            continue
        info = head[1] if kind == "match" else f"{head[3]} | {head[1]}"  # hitch: its summary and GPU
        lines.append(f"{name:40s} {kind:5s}  {info}")
    return "\n".join(lines)


class Handler(BaseHTTPRequestHandler):
    def reply(self, code, text):
        body = (text + "\n").encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def reply_html(self, code, text, ctype="text/html; charset=utf-8"):
        body = text.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def get_stats(self, path, query):
        key = stats_key()
        if not key:
            return self.reply(403, "no stats key yet: run install.sh (it writes /etc/magicfps/stats.key)")
        if not hmac.compare_digest(query.get("key", ""), key):
            return self.reply(403, "add ?key=... (the key is in /etc/magicfps/stats.key)")
        if path in ("/stats", "/stats/"):
            return self.reply_html(200, stats_page.build(STATS_DIR, GAME_STATS_DIR, query))
        if path == "/stats/files":
            return self.reply_html(200, stats_page.file_list(STATS_DIR, GAME_STATS_DIR, key))
        if path.startswith("/stats/raw/"):
            p = stats_page.raw_path(STATS_DIR, GAME_STATS_DIR, urllib.parse.unquote(path[len("/stats/raw/"):]))
            if p:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    return self.reply_html(200, fh.read(), "application/x-ndjson; charset=utf-8")
        self.reply(404, "not found")

    def do_GET(self):
        if self.path == "/health":
            return self.reply(200, "ok")
        url = urllib.parse.urlsplit(self.path)
        if url.path == "/stats" or url.path.startswith("/stats/"):
            query = {k: v[-1] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self.get_stats(url.path, query)
            except Exception as e:  # a bad record must not take the page down
                return self.reply(500, f"stats page failed: {e!r}")
        if self.path in ("/perf", "/perf/"):
            return self.reply(200, perf_index())
        if self.path.startswith("/perf/"):
            name = urllib.parse.unquote(self.path[len("/perf/"):])
            for kind, d, f in perf_files():
                if f == name:  # only names the listing has: no paths
                    with open(os.path.join(d, f), encoding="utf-8", errors="replace") as fh:
                        return self.reply(200, fh.read())
        self.reply(404, "not found")

    def do_POST(self):
        if self.path not in ("/crash", "/perf", "/stats"):
            return self.reply(404, "not found")
        n = int(self.headers.get("Content-Length") or 0)
        stats = self.path == "/stats"
        if n <= 0 or n > (STATS_MAX_BYTES if stats else MAX_BYTES):
            return self.reply(413, "too big")
        now = time.time()
        slot = (self.client_address[0], stats)
        times = [t for t in recent.get(slot, []) if now - t < 3600]
        if len(times) >= (STATS_PER_IP_PER_HOUR if stats else PER_IP_PER_HOUR):
            return self.reply(429, "slow down")
        recent[slot] = times + [now]
        if len(recent) > 10000:  # forget old senders
            for k in [k for k, v in recent.items() if not v or now - v[-1] > 3600]:
                del recent[k]
        data = self.rfile.read(n).decode("utf-8", "replace")
        if stats:
            try:
                save_play_report(data)
            except ValueError:
                return self.reply(400, "not a play report")
            return self.reply(200, "thanks")
        if self.path == "/perf":
            if not data.startswith("Blastcast hitch report"):
                return self.reply(400, "not a hitch report")
            os.makedirs(HITCH_DIR, exist_ok=True)
            print(f"hitch report {save(HITCH_DIR, data)} ({n} bytes)", flush=True)
            return self.reply(200, "thanks")
        if "[FATAL]" not in data and not data.startswith(("Blastcast freeze report", "Blastcast error report")):
            return self.reply(400, "not a crash log")
        print(f"crash report {save(DIR, data)} ({n} bytes)", flush=True)
        self.reply(200, "thanks")

    def log_message(self, *args):
        pass  # no IPs in the journal


def main():
    os.makedirs(DIR, exist_ok=True)
    if len(sys.argv) > 1 and sys.argv[1] in ("list", "show"):
        files = sorted(f for f in os.listdir(DIR) if f.endswith(".txt"))
        if sys.argv[1] == "list":
            for f in files:
                print(f, os.path.getsize(os.path.join(DIR, f)), "bytes")
            print(f"{len(files)} reports in {DIR}")
        elif files:
            print(open(os.path.join(DIR, files[-1 - int(sys.argv[2] if len(sys.argv) > 2 else 0)])).read())
        return
    ThreadingHTTPServer(("", PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
