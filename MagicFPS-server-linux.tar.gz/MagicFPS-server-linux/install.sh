#!/usr/bin/env bash
# Installs or upgrades the Blastcast dedicated server on a Linux host (tested on Ubuntu 24.04).
# Run as root from the unpacked MagicFPS-server-linux folder:  sudo ./install.sh
# Installs to /opt/magicfps, keeps /etc/magicfps/server.env across upgrades, runs the server as the
# unprivileged "magicfps" user under systemd, opens the UDP port in ufw when ufw is active, and enables
# magicfps-update.timer, which installs newer builds from the public magic-fps-releases repo (update.sh).
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
[ "$(id -u)" = 0 ] || { echo "run as root (sudo ./install.sh)" >&2; exit 1; }

id magicfps >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin magicfps

install -d -m 755 /opt/magicfps /opt/magicfps/assets
rm -rf /opt/magicfps/assets/maps
cp -r "$here/assets/maps" /opt/magicfps/assets/
install -m 644 "$here/assets/balance.txt" /opt/magicfps/assets/balance.txt
install -m 755 "$here/magicfps_server" /opt/magicfps/magicfps_server.new
mv -f /opt/magicfps/magicfps_server.new /opt/magicfps/magicfps_server
install -m 755 "$here/update.sh" /opt/magicfps/
install -m 755 "$here/live.sh" /opt/magicfps/
install -m 755 "$here/crash_receiver.py" /opt/magicfps/
install -m 644 "$here/stats_page.py" /opt/magicfps/
install -m 755 "$here/ops_relay.py" /opt/magicfps/
install -m 755 "$here/magicfps-ops-setup" /usr/local/bin/magicfps-ops-setup
printf '#!/bin/sh\nexec /usr/bin/python3 /opt/magicfps/ops_relay.py "${@:-dry-run}"\n' > /usr/local/bin/magicfps-ops
chmod 755 /usr/local/bin/magicfps-ops
printf '#!/bin/sh\nexec /usr/bin/python3 /opt/magicfps/crash_receiver.py "${@:-list}"\n' > /usr/local/bin/magicfps-crashes
chmod 755 /usr/local/bin/magicfps-crashes
ln -sf /opt/magicfps/live.sh /usr/local/bin/magicfps-live
install -m 644 "$here/VERSION.txt" /opt/magicfps/VERSION.txt
install -m 755 "$here/magicfps-config" /usr/local/bin/magicfps-config

install -d -m 755 /etc/magicfps
[ -f /etc/magicfps/server.env ] || install -m 644 "$here/server.env" /etc/magicfps/server.env
# Player stats page key (docs/PLAYER_STATS.md): http://SERVER:27960/stats?key=KEY. Made once; delete it and run this
# again for a new one.
if [ ! -s /etc/magicfps/stats.key ]; then
    head -c 18 /dev/urandom | base64 | tr -d '/+=\n' > /etc/magicfps/stats.key
fi
chown root:magicfps /etc/magicfps/stats.key
chmod 640 /etc/magicfps/stats.key
# The live file (docs/LIVE_FILE.md): the server's own balance and pickups. Updates never replace it.
[ -f /etc/magicfps/live.txt ] || install -m 644 "$here/live.txt" /etc/magicfps/live.txt
# Once: servers installed with the old default of 3 bots start empty now (players add bots from the Esc menu).
if [ ! -e /etc/magicfps/.bots-default-0 ]; then
    sed -i 's/^MF_BOTS=3$/MF_BOTS=0/' /etc/magicfps/server.env
    touch /etc/magicfps/.bots-default-0
fi
# Once: older settings files get the Quick Play settings (matchmaking is on by default; playlist=off turns it off).
grep -q '^MF_PLAYLIST=' /etc/magicfps/server.env || printf '%s\n' '# Quick Play matchmaking: quickplay, off, or MODE:MAP[:PLAYERS[:SCORE]],...' 'MF_PLAYLIST=quickplay' >> /etc/magicfps/server.env
sed -i '/^# Quick Play: people that start a match/d; /^MF_MIN_PLAYERS=/d' /etc/magicfps/server.env  # no longer used
# Once: the lobby's starting team count, and 16 players for servers still on the old default of 8.
grep -q '^MF_TEAMS=' /etc/magicfps/server.env || printf '%s\n' '# Quick Play: the starting number of teams (2-4)' 'MF_TEAMS=2' >> /etc/magicfps/server.env
# Once: the lobby's starting mode and advanced options (magicfps-config mode=... rules=...).
grep -q '^MF_MODE=' /etc/magicfps/server.env || printf '%s\n' '# Quick Play: the starting mode (team, ffa or ctf)' 'MF_MODE=team' >> /etc/magicfps/server.env
grep -q '^MF_MAX_ROOMS=' /etc/magicfps/server.env || printf '%s\n' '# Rooms at once (players open more with NEW ROOM in PLAY ONLINE)' 'MF_MAX_ROOMS=3' >> /etc/magicfps/server.env
grep -q '^MF_DELVE_ROOMS=' /etc/magicfps/server.env || printf '%s\n' '# Delve rooms (docs/DELVE.md), on the ports after the Blastcast rooms: 0 until Delve ships' 'MF_DELVE_ROOMS=0' >> /etc/magicfps/server.env
# The default bots became Apprentice (0.25, rated 800) on 2026-10-15: move the old default along.
sed -i 's/^MF_BOT_SKILL=0.5$/MF_BOT_SKILL=0.25/' /etc/magicfps/server.env
grep -q '^MF_RULES=' /etc/magicfps/server.env || printf '%s\n' '# Quick Play: the starting advanced options (see magicfps-config)' 'MF_RULES=default' >> /etc/magicfps/server.env
if [ ! -e /etc/magicfps/.max-clients-16 ]; then
    sed -i 's/^MF_MAX_CLIENTS=8$/MF_MAX_CLIENTS=16/' /etc/magicfps/server.env
    touch /etc/magicfps/.max-clients-16
fi
for unit in magicfps.service magicfps-update.service magicfps-update.timer magicfps-live.service magicfps-live.timer magicfps-crashes.service magicfps-ops.service magicfps-ops.timer; do
    install -m 644 "$here/$unit" "/etc/systemd/system/$unit"
done

port=$(sed -n 's/^MF_PORT=\([0-9]*\).*/\1/p' /etc/magicfps/server.env | head -n1)
port=${port:-27960}
rooms=$(sed -n 's/^MF_MAX_ROOMS=\([0-9]*\).*/\1/p' /etc/magicfps/server.env | head -n1)
delve=$(sed -n 's/^MF_DELVE_ROOMS=\([0-9]*\).*/\1/p' /etc/magicfps/server.env | head -n1)
last=$((port + ${rooms:-1} + ${delve:-0} - 1))  # rooms after the main one use the next ports, then Delve's
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    if [ "$last" -gt "$port" ]; then ufw allow "$port:$last/udp" comment "Blastcast" >/dev/null; else ufw allow "$port/udp" comment "Blastcast" >/dev/null; fi
    ufw allow 27960/tcp comment "Blastcast crash reports" >/dev/null
    echo "ufw: opened UDP $port-$last and TCP 27960 (crash reports)"
fi

systemctl daemon-reload
systemctl enable magicfps >/dev/null 2>&1
systemctl enable --now magicfps-update.timer >/dev/null 2>&1
systemctl enable --now magicfps-live.timer >/dev/null 2>&1  # does nothing until magicfps-live connect
if command -v python3 >/dev/null 2>&1; then
    systemctl enable magicfps-crashes >/dev/null 2>&1
    systemctl restart magicfps-crashes
    # Crashes and logs to GitHub issues (docs/OPS.md); does nothing until magicfps-ops-setup stores a token.
    systemctl enable --now magicfps-ops.timer >/dev/null 2>&1
    # Preview downloads for Ches's computers (docs/PREVIEW_DOWNLOADS.md); fetch nothing until a token is stored.
    MF_PREVIEW_QUIET=1 "$here/preview_install.sh"
    # Blastcast Bot for the Discord (docs/DISCORD.md): installed everywhere, runs only where blastcast-bot-setup stored
    # its token. It watches every game server over the network, so one host runs it.
    [ -x "$here/discord-bot/install.sh" ] && "$here/discord-bot/install.sh"
    command -v addr2line >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y -qq binutils >/dev/null 2>&1 || true
else
    echo "python3 is missing: crash reports are off (apt install python3, then run this again)"
fi
systemctl restart magicfps
sleep 1
if systemctl is-active --quiet magicfps; then
    echo "Blastcast server is running on UDP $port ($(cat "$here/VERSION.txt" 2>/dev/null || echo unknown build))."
    echo "Logs: journalctl -u magicfps -f    Settings: /etc/magicfps/server.env"
    echo "Auto-update: every 10 minutes from magic-fps-releases (journalctl -u magicfps-update)."
    echo "Live balance and pickups: /etc/magicfps/live.txt (magicfps-live)."
    [ -s /etc/magicfps/github.token ] || echo "Crash and log reports to GitHub are off: run magicfps-ops-setup once (docs/OPS.md)."
    ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "Player stats: http://${ip:-SERVER}:27960/stats?key=$(cat /etc/magicfps/stats.key)"
else
    journalctl -u magicfps -n 20 --no-pager || true
    echo "the server did not start" >&2
    exit 1
fi
