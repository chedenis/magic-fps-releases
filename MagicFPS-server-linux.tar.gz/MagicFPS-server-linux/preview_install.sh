#!/usr/bin/env bash
# Sets up Preview downloads on the server (docs/PREVIEW_DOWNLOADS.md). install.sh runs it on every upgrade
# (MF_PREVIEW_QUIET=1); the first time, Ches runs it from GitHub before a release carries it:
#   read -rsp "Token: " T; echo; curl -fsSL -H "Authorization: Bearer $T" -H "Accept: application/vnd.github.raw" \
#     https://api.github.com/repos/chedenis/magic-fps/contents/packaging/linux-server/preview_install.sh \
#     | MF_PREVIEW_TOKEN="$T" bash
# The token: github.com > Settings > Developer settings > Fine-grained tokens. Repository access: only
# chedenis/magic-fps. Permissions: Contents, read-only. It can't change anything.
# Installs preview.py and its units, makes the page key once, opens TCP 27961, stores the token, and prints the page.
# --update (magicfps-preview-sync.service runs it after every sync): installs main's newest copy of these files when
# preview.py or this script changed on main, so Preview fixes reach the server without a release or SSH.
set -euo pipefail
{
[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
api=https://api.github.com/repos/chedenis/magic-fps/contents/packaging/linux-server
files="preview.py magicfps-preview-web.service magicfps-preview-sync.service magicfps-preview-sync.timer preview_install.sh"
if [ "${1:-}" = --update ]; then
    token=$(cat /etc/magicfps/preview.token 2>/dev/null || true)
    [ -n "$token" ] || exit 0
    new=$(mktemp -d)
    trap 'rm -rf "$new"' EXIT
    for f in $files; do
        curl -fsSL -m 60 -H "Authorization: Bearer $token" -H "Accept: application/vnd.github.raw" "$api/$f" -o "$new/$f" || exit 0
    done
    changed=no
    for f in preview.py preview_install.sh; do cmp -s "$new/$f" "/opt/magicfps/$f" || changed=yes; done
    for f in magicfps-preview-web.service magicfps-preview-sync.service magicfps-preview-sync.timer; do
        cmp -s "$new/$f" "/etc/systemd/system/$f" || changed=yes
    done
    [ "$changed" = yes ] || exit 0
    echo "newer Preview server files on main: installing them"
    MF_PREVIEW_QUIET=1 MF_PREVIEW_TOKEN="$token" bash "$new/preview_install.sh" </dev/null
    exit 0
fi
here=/nonexistent  # piped from curl there is no file, so nothing beside it
[ -n "${BASH_SOURCE[0]:-}" ] && [ -f "${BASH_SOURCE[0]}" ] && here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
token=${MF_PREVIEW_TOKEN:-}
if [ ! -f "$here/preview.py" ]; then  # run from GitHub: fetch the rest the same way
    [ -n "$token" ] || { echo "run it with MF_PREVIEW_TOKEN set (see the top of this file)" >&2; exit 1; }
    here=$(mktemp -d)
    trap 'rm -rf "$here"' EXIT
    for f in $files; do
        curl -fsSL -H "Authorization: Bearer $token" -H "Accept: application/vnd.github.raw" \
            "$api/$f" -o "$here/$f"
    done
fi
id magicfps >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin magicfps
install -d -m 755 /opt/magicfps /etc/magicfps
install -m 755 "$here/preview.py" /opt/magicfps/preview.py
install -m 755 "$here/preview_install.sh" /opt/magicfps/preview_install.sh
for unit in magicfps-preview-web.service magicfps-preview-sync.service magicfps-preview-sync.timer; do
    install -m 644 "$here/$unit" "/etc/systemd/system/$unit"
done
printf '#!/bin/sh\nexec /usr/bin/python3 /opt/magicfps/preview.py "${@:-url}"\n' > /usr/local/bin/magicfps-preview
chmod 755 /usr/local/bin/magicfps-preview
# The page key: made once. Delete /etc/magicfps/preview.key and run this again for a new one; every Preview picks
# the new address up with its next update.
[ -s /etc/magicfps/preview.key ] || head -c 18 /dev/urandom | base64 | tr -d '/+=\n' > /etc/magicfps/preview.key
chown root:magicfps /etc/magicfps/preview.key
chmod 640 /etc/magicfps/preview.key
[ -s /etc/magicfps/preview.host ] || hostname -I 2>/dev/null | awk '{print $1}' > /etc/magicfps/preview.host
if [ -n "$token" ]; then
    umask 077
    printf '%s\n' "$token" > /etc/magicfps/preview.token
    chmod 600 /etc/magicfps/preview.token
    umask 022
fi
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow 27961/tcp comment "Blastcast Preview downloads" >/dev/null
fi
systemctl daemon-reload
systemctl enable magicfps-preview-web >/dev/null 2>&1
systemctl restart magicfps-preview-web
systemctl enable --now magicfps-preview-sync.timer >/dev/null 2>&1
[ "${MF_PREVIEW_QUIET:-}" = 1 ] && exit 0
if [ -s /etc/magicfps/preview.token ]; then
    python3 /opt/magicfps/preview.py check
    echo "Fetching the newest Preview (a minute or two)..."
    systemctl start magicfps-preview-sync || journalctl -u magicfps-preview-sync -n 5 --no-pager
    echo
    echo "Done. Open this on any computer to download the Preview (bookmark it):"
    python3 /opt/magicfps/preview.py url
else
    echo "No token yet: run this again with MF_PREVIEW_TOKEN set (see the top of this file)."
fi
exit 0
}
